import { SelectboxPipe } from './selectbox.pipe';

describe('SelectboxPipe', () => {
  it('create an instance', () => {
    const pipe = new SelectboxPipe();
    expect(pipe).toBeTruthy();
  });
});
