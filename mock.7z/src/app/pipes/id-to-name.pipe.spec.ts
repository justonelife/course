import { IdToNamePipe } from './id-to-name.pipe';

describe('IdToNamePipe', () => {
  it('create an instance', () => {
    const pipe = new IdToNamePipe();
    expect(pipe).toBeTruthy();
  });
});
