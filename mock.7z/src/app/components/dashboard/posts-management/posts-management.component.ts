import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-posts-management',
    templateUrl: './posts-management.component.html',
    styleUrls: ['./posts-management.component.scss']
})
export class PostsManagementComponent implements OnInit {

    constructor() { }

    ngOnInit(): void {
    }

}
