import { EmailValidateDirective } from './email-validate.directive';

describe('EmailValidateDirective', () => {
  it('should create an instance', () => {
    const directive = new EmailValidateDirective();
    expect(directive).toBeTruthy();
  });
});
