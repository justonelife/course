import { PasswordValidateDirective } from './password-validate.directive';

describe('PasswordValidateDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordValidateDirective();
    expect(directive).toBeTruthy();
  });
});
