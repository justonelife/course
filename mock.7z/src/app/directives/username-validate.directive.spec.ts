import { UsernameValidateDirective } from './username-validate.directive';

describe('UsernameValidateDirective', () => {
  it('should create an instance', () => {
    const directive = new UsernameValidateDirective();
    expect(directive).toBeTruthy();
  });
});
